<?php
/**
 *
 * - Zagitanank sdm Language
 *
 * - File : id.php
 * - Version : 1.0
 * - Author : Zagitanank
 * - License : MIT License
 *
*/

$_['component_name'] = 'Data team';
$_['team_title'] = 'Judul';
$_['team_picture'] = "Gambar";
$_['team_notice'] = "<small style='font-size:10px;'>(Size 1140x540 pixel)</small>";
$_['team_date'] = 'Tanggal';
$_['team_active'] = 'Aktif';
$_['team_notactive'] = 'Tidak Aktif';
$_['team_action'] = 'Tindakan';
$_['team_addnew'] = 'Tambah Data';
$_['team_edit'] = 'Update Data';
$_['team_message_2'] = 'team telah berhasil diperbarui';
$_['team_message_3'] = 'team telah berhasil dihapus';
$_['team_message_4'] = 'Kesalahan menambah data team baru';
$_['team_message_5'] = 'Kesalahan memperbarui data team';
$_['team_message_6'] = 'Kesalahan menghapus data team';
$_['team_picture_2'] = 'Tidak Ada Gambar Terpilih';
$_['team_picture_3'] = 'Tidak Ada Gambar Preview';
$_['team_picture_4'] = 'Jika gambar tidak diganti, tidak perlu memilih pilihan di bawah ini.';
$_['team_picture_5'] = 'Gambar Terpilih';
$_['team_picture_6'] = 'Ada Gambar Terpilih';