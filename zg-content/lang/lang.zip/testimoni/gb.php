<?php
/**
 *
 * - Zagitanank sdm Language
 *
 * - File : gb.php
 * - Version : 1.0
 * - Author : Zagitanank
 * - License : MIT License
 *
*/

$_['component_name'] = 'testimoni';
$_['testimoni_title'] = 'Title';
$_['testimoni_picture'] = "Picture";
$_['testimoni_notice'] = "<small style='font-size:10px;'>(Size 1140x540 pixel)</small>";
$_['testimoni_date'] = 'Date';
$_['testimoni_active'] = 'Active';
$_['testimoni_notactive'] = 'Not Active';
$_['testimoni_action'] = 'Action';
$_['testimoni_addnew'] = 'Add testimoni';
$_['testimoni_edit'] = 'Update testimoni';
$_['testimoni_message_2'] = 'testimoni telah berhasil diperbarui';
$_['testimoni_message_3'] = 'testimoni telah berhasil dihapus';
$_['testimoni_message_4'] = 'Kesalahan menambah data testimoni baru';
$_['testimoni_message_5'] = 'Kesalahan memperbarui data testimoni';
$_['testimoni_message_6'] = 'Kesalahan menghapus data testimoni';
$_['testimoni_picture_2'] = 'Tidak Ada Gambar Terpilih';
$_['testimoni_picture_3'] = 'Tidak Ada Gambar Preview';
$_['testimoni_picture_4'] = 'Jika gambar tidak diganti, tidak perlu memilih pilihan di bawah ini.';
$_['testimoni_picture_5'] = 'Gambar Terpilih';
$_['testimoni_picture_6'] = 'Ada Gambar Terpilih';