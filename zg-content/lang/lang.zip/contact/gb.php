<?php
/**
 *
 * - Zagitanank Contact Language
 *
 * - File : gb.php
 * - Version : 1.0
 * - Author : Zagitanank
 * - License : MIT License
 *
*/

$_['component_name'] = 'Contact';
$_['contact_name'] = 'Name';
$_['contact_email'] = 'Email';
$_['contact_subject'] = 'Subject';
$_['contact_message'] = 'Message';
$_['contact_action'] = 'Action';
$_['contact_read'] = 'Mark as Read';
$_['contact_notread'] = 'Mark as Unread';
$_['contact_view'] = 'View';
$_['contact_reply'] = 'Reply';
$_['contact_dialog_title_1'] = 'Detail';
$_['contact_dialog_title_2'] = 'Reply';
$_['contact_message_1'] = 'Contact reply has been successfully sended';
$_['contact_message_2'] = 'Contact has been successfully deleted';
$_['contact_message_3'] = 'Error sended contact reply';
$_['contact_message_4'] = 'Error deleted contact data';
