<?php
/**
 *
 * - Zagitanank registrasi Language
 *
 * - File : id.php
 * - Version : 1.0
 * - Author : Zagitanank
 * - License : MIT License
 *
*/
$_['front_registrasi'] = 'Registrasi';
$_['component_name'] = 'Kontak';
$_['registrasi_name'] = 'Nama';
$_['registrasi_email'] = 'Email';
$_['registrasi_subject'] = 'Subjek';
$_['registrasi_message'] = 'Pesan';
$_['registrasi_action'] = 'Tindakan';
$_['registrasi_read'] = 'Tandai Sudah di Baca';
$_['registrasi_notread'] = 'Tandai Belum di Baca';
$_['registrasi_view'] = 'Lihat';
$_['registrasi_reply'] = 'Balas';
$_['registrasi_dialog_title_1'] = 'Detail';
$_['registrasi_dialog_title_2'] = 'Balas';
$_['registrasi_message_1'] = 'Balasan kontak telah berhasil dikirim';
$_['registrasi_message_2'] = 'Kontak telah berhasil dihapus';
$_['registrasi_message_3'] = 'Kesalahan mengirimkan balasan kontak';
$_['registrasi_message_4'] = 'Kesalahan menghapus data kontak';
