<?php
/**
 *
 * - Zagitanank registrasi Language
 *
 * - File : gb.php
 * - Version : 1.0
 * - Author : Zagitanank
 * - License : MIT License
 *
*/

$_['component_name'] = 'registrasi';
$_['registrasi_name'] = 'Name';
$_['registrasi_email'] = 'Email';
$_['registrasi_subject'] = 'Subject';
$_['registrasi_message'] = 'Message';
$_['registrasi_action'] = 'Action';
$_['registrasi_read'] = 'Mark as Read';
$_['registrasi_notread'] = 'Mark as Unread';
$_['registrasi_view'] = 'View';
$_['registrasi_reply'] = 'Reply';
$_['registrasi_dialog_title_1'] = 'Detail';
$_['registrasi_dialog_title_2'] = 'Reply';
$_['registrasi_message_1'] = 'registrasi reply has been successfully sended';
$_['registrasi_message_2'] = 'registrasi has been successfully deleted';
$_['registrasi_message_3'] = 'Error sended registrasi reply';
$_['registrasi_message_4'] = 'Error deleted registrasi data';
