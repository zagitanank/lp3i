<?php
/**
 *
 * - Zagitanank Contact Language
 *
 * - File : gb.php
 * - Version : 1.0
 * - Author : Zagitanank
 * - License : MIT License
 *
*/

$_['component_name'] = 'Test Participants';
$_['peserta_name'] = 'Name';
$_['peserta_email'] = 'Email';
$_['peserta_kode'] = 'Subject';
$_['peserta_phone'] = 'Phone';
$_['peserta_action'] = 'Action';
$_['peserta_form'] = 'Form';
$_['peserta_date'] = 'Date';
$_['peserta_seleksi'] = 'Selection Results';
$_['peserta_path'] = 'Registration Path';
$_['peserta_berkas'] = 'Berkas';
$_['peserta_path_1'] = 'PMDK / Free Test';
$_['peserta_path_2'] = 'Test';
$_['peserta_dialog_title_1'] = 'Detail';
$_['peserta_dialog_title_2'] = 'Reply';
$_['peserta_message_1'] = 'Contact reply has been successfully sended';
$_['peserta_message_2'] = 'Contact has been successfully deleted';
$_['peserta_message_3'] = 'Error sended contact reply';
$_['peserta_message_4'] = 'Error deleted contact data';
