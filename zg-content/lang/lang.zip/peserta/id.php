<?php

/**
 *
 * - Zagitanank Contact Language
 *
 * - File : id.php
 * - Version : 1.0
 * - Author : Zagitanank
 * - License : MIT License
 *
 */

$_['component_name'] = 'Peserta Seleksi';
$_['peserta_name'] = 'Nama Lengkap';
$_['peserta_email'] = 'Email';
$_['peserta_kode'] = 'Kode Registrasi';
$_['peserta_phone'] = 'No. Ponsel';
$_['peserta_form'] = 'Formulir';
$_['peserta_date'] = 'Tanggal';
$_['peserta_seleksi'] = 'Hasil Seleksi';
$_['peserta_path'] = 'Jalur Pendaftaran';
$_['peserta_berkas'] = 'Berkas';
$_['peserta_path_1'] = 'PMDK / Bebas Tes';
$_['peserta_path_2'] = 'Tes';
$_['peserta_dialog_title_1'] = 'Detail';
$_['peserta_dialog_title_2'] = 'Balas';
$_['peserta_message_1'] = 'Balasan kontak telah berhasil dikirim';
$_['peserta_message_2'] = 'Kontak telah berhasil dihapus';
$_['peserta_message_3'] = 'Kesalahan mengirimkan balasan kontak';
$_['peserta_message_4'] = 'Kesalahan menghapus data kontak';
